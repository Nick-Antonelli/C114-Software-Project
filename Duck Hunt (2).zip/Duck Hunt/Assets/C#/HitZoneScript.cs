﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HitZoneScript : MonoBehaviour {

    //a public variable will show up under the inspector in Unity, and you can edit it in Unity rather than in the script. 
    //a GameObject type is a reference to an object in Unity. In the inspector for the object, drag and drop the referenced GameObject.
    //a Transform type is similar to GameObject, but rather than referencing the GameObject, it only references the position.
    public GameObject crosshair;

    //a Text type is pretty self explanatory. This is so we can increase the score every time a duck is shot
    public Text score;

    public bool colliding = false;

    //public bool Spacebar = false; ||||||   explanation for this line is below

    public float moveSpeed = 10f;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        MoveHitZone();
	}

    void MoveHitZone()
    {
        //a Vector3 is a 3 dimensional position variable. vector(x, y, z)
        //transform.position is the current position of the object.
        Vector3 newPosition = transform.position;
        
        //This code is to make invisible walls for the crosshair. transform.position is not editable directly,
        //so we must make a new variable [newPosition], edit that variable, and then set transform.position to that variable.
        newPosition.x = Mathf.Clamp(newPosition.x, -9, 9);
        newPosition.y = Mathf.Clamp(newPosition.y, -2.8f, 5);
        transform.position = newPosition;
        
        //this moves the crosshair with keyboard or joystick input. It basically says "move the crosshair depending on input, multiplied by speed and time"
        transform.Translate(moveSpeed * Input.GetAxis("Horizontal") * Time.deltaTime, moveSpeed * Input.GetAxis("Vertical") * Time.deltaTime, 0f);

        //*!* this code was for debugging, so I could visually see in unity when the spacebar was pressed
        //if (Input.GetKey("space"))
        //    Spacebar = true;
        //if (!Input.GetKey("space"))
        //    Spacebar = false;
    }

    //This method will run when the crosshair is colliding with some other object.
    private void OnTriggerStay(Collider other)
    {
        //unity has a "Tag" method where you can group multiple objects into one category. In this case, the category is "duck"
        if (other.tag == "duck")
        {
            colliding = true;
            if (Input.GetKeyDown("space"))
                Destroy(other.gameObject);
        }
    }

    //This method runs when the crosshair stops colliding with that object
    private void OnTriggerExit(Collider other)
    {
        if (other.tag == "duck")
            colliding = false;
    }

   
}
