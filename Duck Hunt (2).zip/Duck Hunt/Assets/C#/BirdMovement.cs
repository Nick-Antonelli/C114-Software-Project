﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BirdMovement : MonoBehaviour {
    //Vector3 End_pos;
    //Vector3 Start_pos;
    //public float fraction_of_way_there;
    //public float speed = 5f;
    //public float xPos = 6;//Random.Range(-10,10);
    // Use this for initialization
    void Start () {
        //Start_pos = transform.position;
        //End_pos = transform.position + new Vector3(6, 0, 0);
    }
	
	// Update is called once per frame
	void Update () {
        float xPos = Random.Range(0, 10);
        if(this.transform.position.y < 4)
        {
            xPos = Random.Range(-10, 10);
            //this.transform.position = new Vector2(xPos,)
        }
        //if (fraction_of_way_there < 6)
        //{
        //    fraction_of_way_there += 0.01f;
        //    transform.position = Vector3.Lerp(Start_pos, End_pos, fraction_of_way_there);
        //    transform.Translate(speed * Time.deltaTime, 0, 0);
        //}
        //move object
    }
}
