﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DuckScript : MonoBehaviour {

    public float duckSpeed;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        MoveDuck();
	}

    void MoveDuck()
    {
        Vector3 duckPosition = transform.position;
        duckPosition.x += Time.deltaTime * duckSpeed;
        transform.position = duckPosition;

        if (duckPosition.x > 12 || duckPosition.x < -12)
            Destroy(gameObject);
    }
}
