﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HitZoneScript : MonoBehaviour {

    public GameObject crosshair;

    public bool colliding = false;
    public bool Spacebar = false;
    public float moveSpeed = 10f;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        MoveHitZone();
	}

    void MoveHitZone()
    {
        transform.Translate(moveSpeed * Input.GetAxis("Horizontal") * Time.deltaTime, moveSpeed * Input.GetAxis("Vertical") * Time.deltaTime, 0f);
        if (Input.GetKey("space"))
            Spacebar = true;
        if (!Input.GetKey("space"))
            Spacebar = false;
    }

    private void OnTriggerStay(Collider other)
    {
        if (other.tag == "duck")
        {
            colliding = true;
            if (Input.GetKeyDown("space"))
                Destroy(other.gameObject);
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.tag == "duck")
            colliding = false;
    }

   
}
