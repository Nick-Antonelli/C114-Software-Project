﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HitZoneScript : MonoBehaviour {

    public GameObject crosshair;

    public bool colliding = false;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        MoveHitZone();
	}

    void MoveHitZone()
    {
        Vector2 newPosition = transform.position;
        newPosition = crosshair.transform.position;
        transform.position = newPosition;
    }

    private void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.tag == "duck")
        {
            if (Input.GetButtonDown("Fire1"))
                Destroy(other.gameObject);
        }
    }

    private void OnCollisionExit(Collision other)
    {
        //colliding = false;
    }
}
