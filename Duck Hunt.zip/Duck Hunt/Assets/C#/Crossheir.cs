﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Crossheir : MonoBehaviour {
    public float moveSpeed;
    // Use this for initialization
    void Start () {
        moveSpeed = 10f;

    }

    // Update is called once per frame
    void Update () {
        //Movement of crossheirs using input functions
        transform.Translate(moveSpeed*Input.GetAxis("Horizontal") * Time.deltaTime, moveSpeed * Input.GetAxis("Vertical") * Time.deltaTime, 0f);
        //SpaceBar();
    }

    //void SpaceBar()
    //{
    //    if(Input.GetKey(KeyCode.Space))
    //        {
            
    //        Destroy(gameObject);
    //    }
    //}

    
}
