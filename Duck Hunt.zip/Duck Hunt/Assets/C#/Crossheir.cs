﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Crossheir : MonoBehaviour {
    // Use this for initialization
    void Start () {

    }

    // Update is called once per frame
    void Update () {
        //Movement of crossheirs using input functionsVector2 newPosition = transform.position;
        //newPosition = crosshair.transform.position;
        //transform.position = newPosition;
        //SpaceBar();
    }

    //void SpaceBar()
    //{
    //    if(Input.GetKey(KeyCode.Space))
    //        {
            
    //        Destroy(gameObject);
    //    }
    //}

    
}
