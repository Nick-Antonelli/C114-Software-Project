﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TargetZone : MonoBehaviour {

    public GameObject birdBox;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        MoveTargetZone();
    }

    void MoveTargetZone()
    {
        Vector2 newPosition = transform.position;
        newPosition = birdBox.transform.position;
        transform.position = newPosition;
    }
}
