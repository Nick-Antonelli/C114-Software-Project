﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class fly : MonoBehaviour {
   
    // Use this for initialization
    void Start () {
       
    }
	
	// Update is called once per frame
	void Update () {
        //Create random variable
        float xPos = Random.Range(-5, 5);
        float yVel = Random.Range(0, 5);
        float xVel = Random.Range(-4, 4);

        //Move Object somewhere on the x-axis
        if(this.transform.position.y < -6)
        {
            xPos = Random.Range(-7, 7);

            if (xPos < -3)
                xVel = Random.Range(-1, 6);
            if (xPos > 3)
                xVel = Random.Range(-6, 1);

            this.transform.position = new Vector2(xPos, 6);

            this.GetComponent<Rigidbody2D>().velocity = new Vector2(xVel, yVel);
        }

        //Throw object upwards

        //reset once at botom
    }
}
