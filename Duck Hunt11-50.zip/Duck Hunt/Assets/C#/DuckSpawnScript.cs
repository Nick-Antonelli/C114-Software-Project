﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DuckSpawnScript : MonoBehaviour {

    public Text levelText;

    public GameObject duckPrefab;
    public GameObject duckPrefabLeft;
    public GameObject duckPrefabRight;

    GameObject SpawnPoint;
    public GameObject LeftSpawn;
    public GameObject RightSpawn;

    int randNum;
    Vector3 duckPosition = new Vector3(0, 0, 0);

    public float count;
    public int level;
    public bool spawn = false;

	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void FixedUpdate () {

        count = Mathf.Repeat(Time.time * level, 10);
        //count = Mathf.Round(count);
        if (count % 5 == 0)
            SpawnDuck();
        SetLevel();
	}

    void SpawnDuck()
    {
        randNum = Random.Range(0, 2);
        if (randNum == 0)
        {
            SpawnPoint = LeftSpawn;
            duckPrefab = duckPrefabLeft;
        }
        if (randNum == 1)
        {
            SpawnPoint = RightSpawn;
            duckPrefab = duckPrefabRight;
        }

        randNum = Random.Range(-2, 5);
        duckPosition.y = randNum;
        spawn = true;
        GameObject Duck = Instantiate(duckPrefab, SpawnPoint.transform.position + duckPosition, Quaternion.identity);
    }

    void SetLevel()
    {
        level = int.Parse(levelText.text);
    }
}
