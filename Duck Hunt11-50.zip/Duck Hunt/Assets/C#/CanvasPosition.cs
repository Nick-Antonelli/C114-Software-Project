﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CanvasPosition : MonoBehaviour {

    public Transform scoreBorder;

	// Use this for initialization
	void Start () {
        //transform.position = scoreBorder.transform.position;
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
