﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuSelect : MonoBehaviour {

    void Start()
    {
    }

    private void Update()
    {
        BlueBird();
    }

    public void BlueBird()
    {
        if (Input.GetKey(KeyCode.Space))
        {
            //SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
            SceneManager.LoadScene("OpeningScene", LoadSceneMode.Single);
            gameObject.SetActive(true);
        }
        else if (Input.GetKeyDown(KeyCode.DownArrow))
        {
            gameObject.SetActive(false);

        }
    }
}
